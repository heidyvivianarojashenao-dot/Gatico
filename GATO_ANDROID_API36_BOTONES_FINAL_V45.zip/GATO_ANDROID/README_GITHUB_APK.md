# GATO — APK gratis por GitHub Actions

Este proyecto empaqueta la versión web de GATO V43 dentro de una app Android independiente.
- compileSdk/targetSdk: 36 (Android 16)
- applicationId: com.gato.app
- versionName: 43.0
- No depende de Netlify para funcionar una vez instalada.

## GitHub Actions
Sube este proyecto descomprimido al repositorio y crea `.github/workflows/android.yml` con el workflow de construcción. También puedes subir este ZIP y usar un workflow que lo descomprima, igual que en Botanas.

## Compartir ticket por WhatsApp
La versión 44 prepara la imagen PNG y el mensaje y abre WhatsApp directamente para enviarlos juntos. Si WhatsApp no está instalado, Android muestra el selector normal de aplicaciones.

## Envío de tickets
El botón ENVIAR TICKET usa el mismo flujo de compartir que los recibos de inventario: dentro del APK intenta WhatsApp/WhatsApp Business y, si no están disponibles, muestra el selector de Android. En Chrome/PWA usa Web Share para mostrar las aplicaciones compatibles; si el navegador no permite compartir archivos, guarda el PNG como alternativa.
