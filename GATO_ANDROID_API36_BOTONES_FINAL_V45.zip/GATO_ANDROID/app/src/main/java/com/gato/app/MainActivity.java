package com.gato.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.ClipData;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private WebView printImageWebView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(25, 56, 47));
        getWindow().setNavigationBarColor(Color.rgb(25, 56, 47));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(25, 56, 47));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "GatoAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo abrir el archivo.", Toast.LENGTH_SHORT).show();
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public boolean saveImage(String base64, String fileName) {
            try {
                byte[] bytes = decode(base64);
                String safeName = safeFileName(fileName);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GATO");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                    Uri uri = getContentResolver().insert(collection, values);
                    if (uri == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo abrir el destino");
                        out.write(bytes);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket guardado en Galería > GATO", Toast.LENGTH_SHORT).show());
                    return true;
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GATO");
                    if (!dir.exists() && !dir.mkdirs()) return false;
                    File file = new File(dir, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket guardado.", Toast.LENGTH_SHORT).show());
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean printImage(String dataUrl, String title) {
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/")) return false;
                final String safeTitle = (title == null || title.trim().isEmpty()) ? "GATO" : title.replaceAll("[<>\"&]", "");
                runOnUiThread(() -> {
                    try {
                        if (printImageWebView != null) {
                            printImageWebView.loadUrl("about:blank");
                            printImageWebView.destroy();
                        }
                        printImageWebView = new WebView(MainActivity.this);
                        WebSettings ps = printImageWebView.getSettings();
                        ps.setJavaScriptEnabled(false);
                        ps.setDomStorageEnabled(false);
                        printImageWebView.setBackgroundColor(Color.WHITE);
                        printImageWebView.setWebViewClient(new WebViewClient() {
                            @Override public void onPageFinished(WebView view, String url) {
                                try {
                                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                                    if (pm == null) throw new Exception("PrintManager no disponible");
                                    PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(safeTitle);
                                    pm.print(safeTitle, adapter, new PrintAttributes.Builder()
                                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                            .build());
                                } catch (Exception e) {
                                    Toast.makeText(MainActivity.this, "No se pudo abrir la impresión.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        String html = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><style>html,body{margin:0;padding:0;background:#fff}img{display:block;width:100%;height:auto;margin:0 auto}</style></head><body><img src='" + dataUrl + "' alt='GATO'></body></html>";
                        printImageWebView.loadDataWithBaseURL("https://gato.local/", html, "text/html", "UTF-8", null);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "No se pudo preparar la impresión.", Toast.LENGTH_SHORT).show();
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareText(String text, String title) {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                send.putExtra(Intent.EXTRA_TITLE, title == null ? "GATO" : title);
                runOnUiThread(() -> {
                    try {
                        Intent direct = new Intent(send);
                        direct.setPackage("com.whatsapp");
                        startActivity(direct);
                        return;
                    } catch (ActivityNotFoundException ignored) {}
                    try {
                        Intent directBusiness = new Intent(send);
                        directBusiness.setPackage("com.whatsapp.w4b");
                        startActivity(directBusiness);
                        return;
                    } catch (ActivityNotFoundException ignored) {}
                    try {
                        startActivity(Intent.createChooser(send, title == null ? "Compartir GATO" : title));
                    } catch (Exception ignored) {}
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean printWebView() {
            try {
                PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                if (printManager == null) return false;
                PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("GATO");
                printManager.print("GATO", adapter, new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "No se pudo abrir la impresión.", Toast.LENGTH_SHORT).show());
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareImage(String base64, String fileName, String title, String text) {
            try {
                byte[] bytes = decode(base64);
                String safeName = safeFileName(fileName);
                File dir = new File(getCacheDir(), "shared_images");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }

                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                send.putExtra(Intent.EXTRA_TITLE, title == null ? "GATO" : title);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                send.setClipData(ClipData.newRawUri("GATO", uri));

                // JavascriptInterface se ejecuta fuera del hilo de UI.
                // Todas las aperturas de aplicaciones deben hacerse en el hilo principal.
                runOnUiThread(() -> {
                    try {
                        Intent direct = new Intent(send);
                        direct.setPackage("com.whatsapp");
                        startActivity(direct);
                        return;
                    } catch (ActivityNotFoundException ignored) {}
                    try {
                        Intent directBusiness = new Intent(send);
                        directBusiness.setPackage("com.whatsapp.w4b");
                        startActivity(directBusiness);
                        return;
                    } catch (ActivityNotFoundException ignored) {}
                    try {
                        Intent chooser = Intent.createChooser(send, "Enviar ticket GATO");
                        startActivity(chooser);
                    } catch (Exception ignored) {}
                });
                return true;
            } catch (ActivityNotFoundException e) {
                return false;
            } catch (Exception e) {
                return false;
            }
        }

        private byte[] decode(String value) {
            String v = value == null ? "" : value;
            int comma = v.indexOf(',');
            if (comma >= 0) v = v.substring(comma + 1);
            return Base64.decode(v, Base64.DEFAULT);
        }

        private String safeFileName(String name) {
            String n = name == null ? "Ticket-GATO.png" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!n.toLowerCase().endsWith(".png")) n += ".png";
            return n;
        }
    }

    private boolean openExternalIfNeeded(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return false;
        if (scheme.equals("file") || scheme.equals("about") || scheme.equals("data") || scheme.equals("blob")) return false;
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("whatsapp") || scheme.equals("mailto") || scheme.equals("tel")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) {}
            return true;
        }
        return false;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.loadUrl("about:blank"); webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
